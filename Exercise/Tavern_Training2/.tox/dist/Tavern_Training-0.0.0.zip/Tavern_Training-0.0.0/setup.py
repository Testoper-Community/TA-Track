from distutils.core import setup

setup(
    name='Tavern_Training',
    version='',
    packages=['tests'],
    url='',
    license='',
    author='covid19',
    author_email='',
    description=''
)
